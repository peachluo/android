package com.example.danbuzou;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imv1 = (ImageView)findViewById(R.id.imv);
        imv1.setBackgroundResource(R.drawable.girl);
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void onClick_go(View view){
        TextView tv=(TextView)findViewById(R.id.tv);
        tv.setText("Going");

        ImageView imv = (ImageView)findViewById(R.id.imv);//获取imgview
        AnimationDrawable ad = new AnimationDrawable();

        DisplayMetrics dmt = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dmt);
        float den=dmt.density;

        Bitmap big = BitmapFactory.decodeResource(getResources(), R.drawable.girl);//根据给定资源解析成位图\
        for (int i = 0; i < 16; i++) {
            Bitmap bp = Bitmap.createBitmap(big,(int)((i%4)*80*den), (int)((i/4)*104*den),
                    (int)(80*den), (int)(104*den));
            ad.addFrame(new BitmapDrawable(getResources(),bp),150);//添加帧
        }
        //imv.setBackgroundResource(0);
        imv.setBackground(ad);
        ad.start();
    }
}
