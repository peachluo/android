package com.example.qrscan;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class NumberActivity extends AppCompatActivity
{
    EditText number;
    Button btn_yes2;

    protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_medium);
            Intent in=getIntent();
            //获取组件
            number = (EditText) findViewById(R.id.edit_number2);
            btn_yes2 = (Button) findViewById(R.id.Btn_yes2);
            TextView tx=(TextView)findViewById(R.id.br);
            tx.setText("hh");
            //创建监听
        btn_yes2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //获取输入内容
                String str_num=number.getText().toString();
                //如果输入内容为空
                if(str_num==null||str_num.length()==0){
                    return;
                }
                else {
                    String str = (String) getIntent().getStringExtra("data");
                    String tag = str.split(",")[0];
                    int person = Integer.parseInt(str.split(",")[1]);
                    int sum = Integer.parseInt(str.split(",")[2]);
                    int nowper=Integer.parseInt(str.split(",")[3]);
                    //判断目前人数
                    //如果是第一轮
                    if(tag.equals("F")){
                        //数字相加
                        sum+=Integer.parseInt(str_num);
                        if(nowper<person){
                            nowper++;
                        }
                        //如果人数已满进入第二轮
                        else if(nowper==person){
                            tag="S";
                            nowper=1;
                        }
                        str=tag+","+person+","+sum+","+nowper;
                        //跳转到生成二维码界面
                        Intent intent = new Intent(NumberActivity.this, QRActivity.class);
                        intent.putExtra("data", str);
                        startActivity(intent);
                    }
                    //如果是第二轮
                    else if(tag.equals("S")){
                        sum-=Integer.parseInt(str_num);
                        if(nowper<person){
                            nowper++;
                            str=tag+","+person+","+sum+","+nowper;
                            //跳转到生成二维码界面
                            Intent intent = new Intent(NumberActivity.this, QRActivity.class);
                            intent.putExtra("data", str);
                            startActivityForResult(intent,0);
                        }
                        else if(nowper==person){
                            //跳转到结果页面
                            Intent intent = new Intent(NumberActivity.this, Result.class);
                            intent.putExtra("result", "平均数为："+sum/person+"参与人数："+person);
                            startActivity(intent);
                        }
                    }

                }
            }
        });
    }
}
