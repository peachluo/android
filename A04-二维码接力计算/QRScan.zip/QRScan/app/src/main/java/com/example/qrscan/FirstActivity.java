package com.example.qrscan;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class FirstActivity  extends AppCompatActivity
{
    Button btn_yes;
    EditText edit_number;
    EditText edit_person;
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        //获取组件
        btn_yes=(Button)findViewById(R.id.Btn_yes);
        edit_number=(EditText)findViewById(R.id.edit_number);
        edit_person=(EditText)findViewById(R.id.edit_person);

            btn_yes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{ //设置监听
                    //获取输入信息
                    String str_num=edit_number.getText().toString();
                    String str_per=edit_person.getText().toString();
                    //如果为空
                    if(str_per==null||str_per.length()==0||str_num==null||str_num.length()==0||str_per.equals("1")){
                        TextView tx= (TextView)findViewById(R.id.helo);
                        tx.setText("输入不合法");
                        return;
                    }
                    else {
                        String str="F,"+str_per+","+str_num+",2";
                        Intent intent = new Intent(FirstActivity.this, QRActivity.class);
                        intent.putExtra("data", str);
                        startActivityForResult(intent, 0);
                    }
                    }
                    catch (Exception e){
                        TextView tx= (TextView)findViewById(R.id.helo);
                        tx.setText(e+"");
                    }
                }

            });

    }
}
