package com.example.qrscan;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Result extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result);
        Intent in=getIntent();
        String str=in.getStringExtra("result");
        TextView tx=(TextView)findViewById(R.id.result);
        tx.setText(str);
    }
}
