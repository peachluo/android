package com.example.qrscan;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.yzq.zxinglibrary.android.CaptureActivity;
import com.yzq.zxinglibrary.common.Constant;

import static com.yzq.zxinglibrary.encode.CodeCreator.createQRCode;

public class QRActivity extends AppCompatActivity {
    ImageView image;
    Button btn_scan2;
    private String tag,content;
    private int number;
    private int REQUEST_CODE_SCAN=222;
    private int person,nowper;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr);
        //获取组件
        btn_scan2=(Button)findViewById(R.id.Btn_scan2);
        image=(ImageView)findViewById(R.id.imageView);
        //获取信息
        getDatas();
        //生成二维码
        initQR();
        //注册监听
        btn_scan2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(QRActivity.this, CaptureActivity.class);
                startActivityForResult(intent, REQUEST_CODE_SCAN);
            }
        });
    }

    private void getDatas(){
        try {
            content = (String) getIntent().getStringExtra("data");
            tag = content.split(",")[0];
            person = Integer.parseInt(content.split(",")[1]);
            number = Integer.parseInt(content.split(",")[2]);
            nowper=Integer.parseInt(content.split(",")[3]);
        }
        catch (Exception e){
            TextView tx= (TextView)findViewById(R.id.heo);
            tx.setText(e+"");
        }
    }

    private void initQR() {
        try {
            String str = tag + "," + person + "," + number+","+nowper;
            Bitmap bitmap = createQRCode(str, 400, 400, null);
            if (bitmap != null) {
                image.setImageBitmap(bitmap);
            }
        }
        catch (Exception e){
            TextView tx= (TextView)findViewById(R.id.heo);
            tx.setText(tag+person+number+nowper+e+"");
        }
    }
    //扫描后
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // 扫描二维码/条码回传
        if (requestCode == REQUEST_CODE_SCAN && resultCode == RESULT_OK) {
            if (data != null) {
                //如果当前页面扫描完是第二轮得话可进入减法计算
                content = data.getStringExtra(Constant.CODED_CONTENT);
                tag=content.split(",")[0];
                if(tag.equals("F")){
                    return;
                }
                else{
                    Intent intent = new Intent(QRActivity.this, NumberActivity.class);
                    intent.putExtra("data", content);
                    startActivity(intent);

                }
            }
        }
    }
}
