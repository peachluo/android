package com.example.qrscan;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.yzq.zxinglibrary.android.CaptureActivity;
import com.yzq.zxinglibrary.common.Constant;

public class MainActivity extends AppCompatActivity {
    Button btn_scan;
    Button btn_first;
    private int REQUEST_CODE_SCAN = 111;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //获取组件
        btn_first=(Button)findViewById(R.id.Btn_first);
        btn_scan=(Button)findViewById(R.id.Btn_scan);
        //扫一扫
        btn_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            //申请相机权限
            public void onClick(View v) {
            Permisson.requestPermission(MainActivity.this,
                    new String[]{
                            Manifest.permission.CAMERA,
                            Manifest.permission.READ_EXTERNAL_STORAGE
                    }, 1);
            Intent intent = new Intent(MainActivity.this, CaptureActivity.class);
            startActivityForResult(intent, REQUEST_CODE_SCAN);
            }
        });
            //发起
            btn_first.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent intent = new Intent(MainActivity.this, FirstActivity.class);
                        startActivity(intent);
                    } catch (Exception e) {
                        TextView tx = (TextView) findViewById(R.id.main);
                        tx.setText(e + "");
                    }
                }
            });
        }

    //扫描二维码回传
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            // 扫描二维码/条码回传
            if (requestCode == REQUEST_CODE_SCAN && resultCode == RESULT_OK) {
                TextView tx = (TextView) findViewById(R.id.main);
                if (data != null) {
                    try {
                        String content = data.getStringExtra(Constant.CODED_CONTENT);
                        tx.setText(content);
                        String tag = content.split(",")[0];
                        if (tag.equals("F")) {
                            Intent intent = new Intent(MainActivity.this, NumberActivity.class);
                            intent.putExtra("data", content);
                           startActivity(intent);
                        } else {
                            tx.setText("无法参与");
                            return;
                        }
                    }
                    catch (Exception e){

                        tx.setText(e + "");
                    }
                }
            }

    }
}
