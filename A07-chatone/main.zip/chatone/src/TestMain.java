import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;


public class TestMain implements Runnable{
    String strsend;
    public static void main(String[] args) {
        Thread myThread = new Thread(new TestMain());
        myThread.start();

    }

    @Override
    public void run() {
        try {
            @SuppressWarnings("resource")
            ServerSocket serverSocket = new ServerSocket(4000);
            System.out.println("对话开始");
            while (true) {
                Socket client = serverSocket.accept();
                try {
                    //接收客户端的数据
                    BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream(),"utf-8"));
                    String str = in.readLine();
                    System.out.println("接收到客户端:" + str);
                    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                    System.out.print("请发送消息：");
                         //从控制台读取一行数据，返回值字符串
                    strsend = br.readLine();
                    //返回数据给客户端
                    PrintWriter pout = new PrintWriter(new OutputStreamWriter(client.getOutputStream(), "utf-8"));
                    if(strsend!=null)
                       pout.println(strsend);
                    pout.close();
                    in.close();
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                    e.printStackTrace();
                } finally {
                    client.close();
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }


}