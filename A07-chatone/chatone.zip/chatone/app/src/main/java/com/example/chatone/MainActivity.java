package com.example.chatone;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private EditText mEditText;
    private Button mButton;
    private String sendMesg;
    private Socket socket;
    TextView tv;
    String recvMsg="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mEditText = (EditText)findViewById(R.id.mEditText);
        tv=(TextView)findViewById(R.id.tv);
        mButton = (Button) this.findViewById(R.id.mButton);
        mButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                sendMesg = mEditText.getText().toString();
                new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            socket = new Socket("192.168.137.1", 4000);

                            //向服务器发送数据
                            PrintWriter send = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(),"utf-8")));
                            send.println(sendMesg);

                            send.flush();

                            //接受服务端数据
                            BufferedReader recv = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            recvMsg += recv.readLine()+"\n";
                            if (recvMsg != null) {
                                tv.setText("接受到服务器:"+recvMsg);
                            } else {
//                          mRecvText.setText("Cannot receive data correctly.");
                            }

                            send.close();
                            recv.close();
                            socket.close();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }

                }).start();
            }
        });
    }
}