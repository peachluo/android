package com.example.p_mediaplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;

public class SongActivity extends AppCompatActivity {
    Chronometer starttime;
    TextView endtime;
    LyricsView lyric;
    String url,title,author;
    int duration;
    MediaPlayer mediaPlayer=null;
    SeekBar seekBar;
    String cc="";
    long flagtime=0,pausetime=0,begintime=0,subtime=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_view);
        //先获取数据
        Intent intent=getIntent();
        url=intent.getStringExtra("url");
        title=intent.getStringExtra("title");
        author=intent.getStringExtra("author");
        duration=intent.getIntExtra("duration",0);
        //再初始化
        init();
    }
    private void init() {
        //获取组件
        Button btn_pause=(Button)findViewById(R.id.btn_pause);
        Button btn_play=(Button)findViewById(R.id.btn_play);
        seekBar=(SeekBar)findViewById(R.id.seekBar);
        seekBar.setEnabled(false);
        starttime=(Chronometer)findViewById(R.id.starttime);
        starttime.setFormat("%s");
        endtime=(TextView)findViewById(R.id.endtime);
        lyric=(LyricsView) findViewById(R.id.lyric);
        //设置音乐总时间
        String s=FormatTime(duration);
        endtime.setText(s);

        //为按钮绑定事件
        btn_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mediaPlayer==null){
                    mediaPlayer=new MediaPlayer();
                    try {
                        seekBar.setEnabled(true);
                        seekBar.setMax(duration);
                        //设置播放时间
                        flagtime=SystemClock.elapsedRealtime();
                        starttime.setBase(flagtime);
                        starttime.start();
                        //获取歌词
                        getLrc();
                        //播放
                        mediaPlayer.setDataSource(url);
                        mediaPlayer.prepare();
                        mediaPlayer.start();
                        handler.postDelayed(run,100);
                        //当音乐播放完
                        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                            @Override
                            public void onCompletion(MediaPlayer mp) {
                                mediaPlayer.release();
                                mediaPlayer=null;
                                starttime.stop();
                                subtime=0;
                            }
                        });
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                else if(mediaPlayer!=null&&!mediaPlayer.isPlaying()){
                    mediaPlayer.start();
                    subtime+=SystemClock.elapsedRealtime()-pausetime;
                    begintime=flagtime+subtime;
                    starttime.setBase(begintime);
                    starttime.start();
                }
            }
        });
        btn_pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mediaPlayer!=null&&mediaPlayer.isPlaying()){
                    mediaPlayer.pause();
                    starttime.stop();
                    pausetime = SystemClock.elapsedRealtime();
                }
            }
        });
        //为seekbar绑定事件
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                handler.removeCallbacks(run);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                subtime=0;
                mediaPlayer.seekTo(seekBar.getProgress());
                flagtime=SystemClock.elapsedRealtime()-seekBar.getProgress();
                starttime.setBase(flagtime);
                handler.postDelayed(run,1000);
            }
        });
    }
    Handler handler=new Handler();
    Runnable run=new Runnable() {
        @Override
        public void run() {
            if(mediaPlayer!=null) {
                seekBar.setProgress(mediaPlayer.getCurrentPosition());
                handler.postDelayed(run, 100);
            }
        }
    };

    /*时间换算*/
    protected String FormatTime(int time){
        String t="";
        if(time/1000%60<10){
            t=time/1000/60+":0"+time/1000%60;
        }
        else {
            t=time/1000/60+":"+time/1000%60;
        }
        return t;
    }
    /*返回*/
    public void onBackPressed(){
        Intent mIntent =new Intent(this, MainActivity.class);
        if(mediaPlayer!=null) {
            mediaPlayer.stop();
        }
        finish();
        startActivity(mIntent);
    }
    /*下载歌词*/
    StringBuffer tw_page;
    String result;
    String save_url= Environment.getExternalStorageDirectory()+"/AndroidTask/mp/lrc/";//获取sd卡根路径
    String lrc_url= "https://www.22lrc.com/";
    public void getLrc(){
        new Thread(new Runnable(){
            @Override
            public void run() {
                try {
                    //获取歌曲信息
                    String title_utf= URLEncoder.encode(title,"utf-8");
                    String author_utf=URLEncoder.encode(author,"utf-8");
                    String url_str="https://www.22lrc.com/search.php?keyword="+title_utf+author_utf+"&radio=3";
                    // 打开URL链接
                    URL url=new URL(url_str);
                    HttpsURLConnection connection=(HttpsURLConnection) url.openConnection();
                    connection.addRequestProperty("User-Agent","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0");
                    connection.connect();
                    if(connection.getResponseCode()==HttpsURLConnection.HTTP_OK){
                        InputStream in=connection.getInputStream();
                        InputStreamReader r=new InputStreamReader(in);
                        BufferedReader bufferedReader=new BufferedReader(r);
                        tw_page=new StringBuffer();
                        String line=null;
                        while ((line=bufferedReader.readLine())!=null){
                            tw_page.append(line);
                        }
                    }
                    //根据tw_page获取下载链接getHref
                    onPostExecute();
                    //获取result在href之后的数值
                    Log.i("tt",result);
                    int indexofhref=0;
                    indexofhref=result.indexOf("href=");
                    Log.i("tt",indexofhref+"");
                    int indexofend=0;
                    indexofend=result.indexOf("\">");
                    Log.i("tt",indexofend+"");
                    result=result.substring(indexofhref+6,indexofend);
                    String urlll=lrc_url+result;
                    boolean rr=requestByGet(urlll,save_url,title+"-"+author+".lrc");

                    //调用getString4Local本体读取歌词文件
                    String lrcpath=save_url+title+"-"+author+".lrc";
                    cc=getString4Local(lrcpath);
                    //lyric.setText("6");
                    if(cc.equals("")){
                        cc="找不到歌词";
                    }
                    //使用
                    lyric.setLrc(cc);
                    lyric.setPlayer(mediaPlayer);
                    lyric.init();
                } catch (Exception e) {
                    //lyric.setText("出现异常"+e);
                }
            }
        }).start();
    }
    protected void onPostExecute() {
        //获取
        String tagA="<a class=\"adw\" href=\"";
        String tagB="</a";
        String left=tw_page.toString();

        int start=left.indexOf(tagA);
        Log.i("tt",start+"");
        int len = left.length();
        Log.i("tt",len+"");

        if (start>=0) {
            left = left.substring(start);
            Log.i("tt",left);
            int end = left.indexOf(tagB);
            if (end>=0) {
                String p1=left.substring(0, end);
                //p1就是了
                result=p1;
            }
        }

        Log.i("tt",result);
    }
    /*得到lrc文件下载本地*/
    public boolean requestByGet(String path, String save_path, String filename) throws Exception {
        URL url = new URL(path);
        HttpsURLConnection urlConn = (HttpsURLConnection) url.openConnection();
        urlConn.setConnectTimeout(5 * 1000);
        urlConn.connect();
        // 判断请求是否成功
        Log.i("tt",urlConn.getResponseCode()+"");
        if (urlConn.getResponseCode() == 200) {
            // 获取响应的输入流对象
            InputStream is = urlConn.getInputStream();
            Log.i("tt","ss");
            File file1 = new File(save_path);
            if (!file1.exists()) {
                file1.mkdirs();
            }
            File file = new File(save_path + filename);
            Log.i("tt","ss");
            InputStreamReader isr=new InputStreamReader(is, "gbk");
            BufferedReader br=new BufferedReader(isr);


            FileOutputStream out = new FileOutputStream(file);

            OutputStreamWriter osw=new OutputStreamWriter(out, "gbk");
            BufferedWriter bw=new BufferedWriter(osw);
            String ss="";
            while ((ss=br.readLine())!=null) {
                bw.write(ss);
                bw.newLine();
            }
            // 释放资源
            bw.close();
            br.close();

            urlConn.disconnect();
            Log.i("tt","ss");
            return true;
        } else {
            Log.i("GET", "Get方式请求失败");
        }
        // 关闭连接
        urlConn.disconnect();
        return false;
    }
    /*本地读取歌词文件*/
    protected String getString4Local(String path) {
        try {
            InputStream in = new FileInputStream(new File(path));
            ByteArrayOutputStream os = new ByteArrayOutputStream();

            byte[] buffer = new byte[1024];
            int len = -1;
            while ((len = in.read(buffer)) != -1) {
                os.write(buffer, 0, len);
            }
            return os.toString("gbk");    //文件编码是GBK的

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }
}
