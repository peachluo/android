package com.example.p_mediaplayer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActicity";
    private ArrayList<HashMap<String, Object>> musiclist;
    private Context mContext;
    Intent intent=null;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //获取组件
        ListView lv = (ListView) findViewById(R.id.id_list);
        //获取存储权
        mContext = this;
        writeSdcard();
        getPermission();
        //为listview设置adapter
        musiclist = scanAllAudioFiles();
        if (musiclist.size() == 0) {
            Log.e("PRINT", "没有data");
        } else {
            Log.e("PRINT", "有data");
            final SimpleAdapter adapter = new SimpleAdapter(this, musiclist, R.layout.item,
                    new String[]{"music_title"},//Map哪些key对应的value
                    new int[]{R.id.fileName});//填充组件
            lv.setAdapter(adapter);
            //为list中的item注册监听
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
                    HashMap<String, Object> temp=musiclist.get(position);
                    Log.e("tt", (String) temp.get("music_title"));
                    Log.e("tt", (String) temp.get("music_url"));
                    if (intent == null) {
                        intent = new Intent(MainActivity.this, SongActivity.class);
                        intent.putExtra("url", (String) temp.get("music_url"));
                        intent.putExtra("title", (String) temp.get("music_title"));
                        intent.putExtra("author",(String) temp.get("music_author"));
                        intent.putExtra("duration", (Integer) temp.get("music_duration"));
                        startActivity(intent);
                    }
                    else {
                        Toast.makeText(MainActivity.this,"还有歌曲在播放",Toast.LENGTH_SHORT);
                    }
                }
            });
        }

    }

    //返回音乐的ArrayList
    public ArrayList<HashMap<String, Object>> scanAllAudioFiles() {
        //生成动态集合，用于存储数据
        ArrayList<HashMap<String, Object>> mylist = new ArrayList<HashMap<String, Object>>();
        //查询媒体数据库
        Cursor cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null, null, null, MediaStore.Audio.Media.DEFAULT_SORT_ORDER);
        //遍历媒体数据库
        if (cursor != null) {
            if (cursor.moveToFirst()) {

                while (!cursor.isAfterLast()) {
                    //歌曲名
                    String title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE));
                    //歌曲的歌手名： MediaStore.Audio.Media.ARTIST
                    String author = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST));
                    //歌曲文件的路径 ：MediaStore.Audio.Media.DATA
                    String url = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA));
                    //歌曲的总播放时长 ：MediaStore.Audio.Media.DURATION
                    int duration = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION));
                    //歌曲文件的大小 ：MediaStore.Audio.Media.SIZE
                    Long size = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE));

                    if (!author.contains("unknown")) {
                        if (size > 1024 * 800) {//如果文件大小大于800K，将该文件信息存入到map集合中
                            HashMap<String, Object> map = new HashMap<String, Object>();
                            map.put("music_title", title);
                            map.put("music_author", author);
                            map.put("music_url", url);
                            map.put("music_duration", duration);
                            mylist.add(map);
                        }
                    }
                    cursor.moveToNext();
                }
            }
        }
        //返回存储数据的集合
        return mylist;
    }

    private void getPermission() {
        //检查权限是否存在
        if (ContextCompat.checkSelfPermission(mContext,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            //向用户申请授权
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
            }, 1);

        } else {
            writeSdcard();
        }
    }

    private void writeSdcard() {

        if (Environment.MEDIA_MOUNTED.equals(
                Environment.getExternalStorageState())) {

            File extDir = Environment.getExternalStorageDirectory();
            File goalFile = new File(extDir, "writeSdcard.txt");

            try {
                BufferedWriter bw = new BufferedWriter(new FileWriter(goalFile));
                BufferedReader br = new LineNumberReader(new FileReader(goalFile));

                bw.write("Write writeSdcard data");
                bw.flush();

                String len;
                while ((len = br.readLine()) != null) {
                    Log.i(TAG, len);
                }

                br.close();
                bw.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            Log.i(TAG, "SDCard not exists");
        }
    }
}
