package com.example.pro01_feihualing;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    private Button btn1;
    private EditText text;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1=(Button)findViewById(R.id.btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("test1");
                text = (EditText)findViewById(R.id.text);
                if(text.length()!=0){
                    showPoem(text.getText().toString());
                    hideInput();//隐藏输入法
                }
            }
        });
    }
    public void hideInput() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        View v = getWindow().peekDecorView();
        if (null != v) {
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }
    }
    public void showPoem(String str){
        System.out.println(str);
        textView = (TextView)findViewById(R.id.textView);
        textView.setMovementMethod(ScrollingMovementMethod.getInstance());//可以支持对TextView的内容滑动
        textView.setHorizontallyScrolling(true);//设置文本框是否可以水平地进行滚动
        InputStream context = this.getClass().getResourceAsStream("/assets/poems");//从根目录读取
        BufferedReader br = new BufferedReader(new InputStreamReader(context));//BufferedReader读取文本文件
        String line,title="",result="";
        int count=0;
        try{
            while((line=br.readLine())!=null) {
                if (line.length() == 0) {
                    continue;
                }
                if ('0' <= line.charAt(0) && line.charAt(0) <= '9') {
                    title = line.substring(3, line.length());//前3个数为序号 后为标题
                    continue;//substring() 方法返回的子串包括 start 处的字符,但不包括 stop 处的字符
                }
                if (line.contains((str))) {
                    result += (++count) + "." + line + ' ' + title + "\n";//使用空格分隔标题和诗句
                }
            }
            SpannableString ss=new SpannableString(result);
            for(int i=0;i<=result.length()-str.length();i++){
                if(result.substring(i,i+str.length()).equals(str)){//找到str并标识
                    ForegroundColorSpan colorSpan1=new ForegroundColorSpan(Color.parseColor("#FF0000"));
                    ss.setSpan(colorSpan1,i,i+str.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    i+=str.length()-1;
                }
                else if(result.charAt(i)==' '){//标题灰色
                    int j=i;
                    ForegroundColorSpan colorSpan2=new ForegroundColorSpan(Color.BLACK);
                    while(result.charAt(i)!='\n') i++;
                    ss.setSpan(colorSpan2,j,i, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
            TextView tx=(TextView)findViewById(R.id.notify);
            tx.setText("一共查找到"+count+"句");
            textView.setText(ss);
        }
        catch (IOException e){

        }
    }
}
