package com.example.html;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private WebView wbview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wbview=(WebView)findViewById(R.id.id_wbview);
        // 启用javascript
        wbview.getSettings().setJavaScriptEnabled(true);
        // 加载
        wbview.loadUrl("file:///android_asset/login.html");
        wbview.addJavascriptInterface(MainActivity.this,"android");
    }
    //由于安全原因 需要加 @JavascriptInterface
    @JavascriptInterface
    public void startFunction(final String str){
        Toast.makeText(MainActivity.this,"js调用android方法:"+str, Toast.LENGTH_SHORT).show();
    }
}
