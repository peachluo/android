package com.example.p_gpsclock;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.text.method.DigitsKeyListener;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static java.lang.Math.abs;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private LocationManager mManager;
    private double golng=0;//目的地坐标
    private double golat=0;
    private double lng=0;//当前坐标
    private double lat=0;
    private Button button;
    private boolean setOk=false;//目的地设置判定
    MediaPlayer mMediaPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        获取组件
        button=(Button)findViewById(R.id.id_button);
        mMediaPlayer = MediaPlayer.create(this, R.raw.music);
        mMediaPlayer.setLooping(true);
//        加载网页
        webView = (WebView) findViewById(R.id.id_webview);
        //webView.setInitialScale(250);
        webView.loadUrl("file:///android_asset/index.html");
//        调整网页
        WebSettings settings=webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
//        加载js
        webView.setWebViewClient(new MyWebViewClient());
        webView.setWebChromeClient(new MyWebChromeClient());
//        获取位置
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 10);
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 10);
        mManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setCostAllowed(true);
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        String provider = mManager.getBestProvider(criteria, true);
        Log.d("报错", provider);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(),"没有权限,请手动开启定位权限",Toast.LENGTH_SHORT).show();
            return;
        }

        mManager.requestLocationUpdates(provider, 3000, 0, mLocationListener01);
        Location location = mManager.getLastKnownLocation(provider);

        updateWithNewLocation(location);
        //添加监听
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                webView.loadUrl("javascript:leafletMap.panTo(["+lat+","+lng+"])");
            }
        });
        //绑定js
        webView.addJavascriptInterface(new WebAppInterface(new WebAppInterface.Callback() {
            @Override
            public void onSetValue(double lat, double lng) {
                //Toast.makeText(getApplicationContext(),"方法调用："+lat+","+lng,Toast.LENGTH_SHORT).show();
                golat = lat;
                golng = lng;
                setOk = true;
            }
        }), "data");
    }
    private void updateWithNewLocation(Location location) {
        if (location != null) {
            lat = location.getLatitude();
            lng = location.getLongitude();
        } else {
            Toast.makeText(getApplicationContext(),"无法获取地理信息",Toast.LENGTH_SHORT).show();
        }
    }
    private class MyWebViewClient extends WebViewClient{
        @Override
        public void onPageFinished(WebView view, String url) {

            super.onPageFinished(view, url);
        }
    }
    private class MyWebChromeClient extends WebChromeClient{
        public void onProgressChanged(final WebView view, int newProgress){
            if (newProgress == 100) {
                view.loadUrl("javascript:gotoxy("+lat+","+lng+")");
                view.loadUrl("javascript:leafletMap.panTo(["+lat+","+lng+"])");
            }
            super.onProgressChanged( view,  newProgress);
        }
    }
    public final LocationListener mLocationListener01 = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {

            updateWithNewLocation(location);
            if(setOk)
            {
                if (abs(golat - lat) < 0.001 && abs(golng - lng) < 0.001) {
                    setOk = false;
                    mMediaPlayer.start();
                    AlertDialog aDialog = new AlertDialog.Builder(MainActivity.this)
                            .setMessage("已到达")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    mMediaPlayer.stop();
                                    mMediaPlayer= MediaPlayer.create(MainActivity.this, R.raw.music);
                                }
                            }).create();
                    aDialog.show();
                }
            }
            webView.loadUrl("javascript:gotoxy("+lat+","+lng+")");
        }
        @Override
        public void onProviderDisabled(String provider) {

        }
        @Override
        public void onProviderEnabled(String provider) {}

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {}
    };
    @JavascriptInterface
    public void setTarget(double thelat,double thelng){
        golat=thelat;
        golng=thelng;
        Toast.makeText(getApplicationContext(),"更新目的地："+golat+","+golng,Toast.LENGTH_SHORT).show();
    }
}

