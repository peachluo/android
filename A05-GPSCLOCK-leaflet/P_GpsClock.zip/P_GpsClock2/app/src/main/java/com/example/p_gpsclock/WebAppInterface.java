package com.example.p_gpsclock;

import android.content.Context;
import android.webkit.JavascriptInterface;

public class WebAppInterface {
    private static final String TAG = WebAppInterface.class.getSimpleName();
    private Callback mCallback;

    public WebAppInterface(Callback callback) {
        mCallback = callback;
    }

    @JavascriptInterface
    public void setValue(double lat, double lng) {
        if (mCallback != null) {
            mCallback.onSetValue(lat, lng);
        }
    }

    public interface Callback {
        void onSetValue(double lat, double lng);
    }
 }